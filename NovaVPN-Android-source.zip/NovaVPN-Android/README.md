# NovaVPN Android — исходный проект

Это исходный проект Flutter для Android. Он использует `sing_box` (обёртку над sing-box/libbox) для Android VPN service и поддерживает импорт ссылок VLESS и Shadowsocks в указанной реализации.

## Важно

- Это **исходный проект, не готовый APK**.
- Пакет `sing_box` версии `0.0.1` помечен автором как экспериментальный/нестабильный. Сборку и VPN-соединение необходимо проверить на реальном устройстве.
- Приложение не содержит собственных VPN-серверов и не предоставляет подписку. Нужна действующая ссылка от провайдера, которой пользователь вправе пользоваться.
- Протоколы/транспорты, которые не поддержаны парсером этого starter-проекта, будут пропущены. Сейчас реализованы VLESS TCP/TLS/Reality, WebSocket, gRPC, HTTPUpgrade и Shadowsocks URI. XHTTP, VMess, Trojan, Hysteria и SSR не реализованы в этом starter.
- Ссылка подписки и конфигурации сохраняются в Android Keystore-backed secure storage через `flutter_secure_storage`; всё равно не передавайте секретную ссылку посторонним.
- При первом подключении Android покажет системный запрос разрешения на VPN.
- Ping измеряется средствами VPN-движка после подключения; точность зависит от реализации плагина и сервера.

## Требования

- Flutter stable (Dart 3.3+)
- Android Studio / Android SDK
- JDK 17
- Android 7.0+ (minSdk 24)

## Сборка на компьютере

1. Установить Flutter и Android Studio.
2. Распаковать архив.
3. В папке проекта выполнить:

```bash
flutter create . --platforms=android
flutter pub get
flutter run
```

Для APK:

```bash
flutter build apk --release
```

Файл будет создан здесь:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## Сборка через GitHub Actions

В проект включён workflow `.github/workflows/build-android.yml`. Загрузите исходники в собственный GitHub-репозиторий и запустите workflow `Build NovaVPN Android APK`. После успешной сборки APK появится в Artifacts.

## Форматы

Подписки могут быть обычным текстом с одной ссылкой на строку или Base64-текстом, который декодируется в список ссылок. Импортируются `vless://` и `ss://`.

## Лицензии

В проекте используется Flutter package `sing_box`, который включает sing-box/libbox. Учитывайте лицензионные условия sing-box (GPL-3.0-or-later), условия зависимостей и требования к атрибуции, если распространяете приложение.
