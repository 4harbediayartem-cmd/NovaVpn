import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sing_box/sing_box.dart';

const _storage = FlutterSecureStorage();
const _sourcesKey = 'nova.subscription.sources.v1';
const _themeKey = 'nova.theme.color.v1';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  var coreReady = false;
  String? startupError;
  try {
    coreReady = await SingBox.instance.initialize();
    if (!coreReady) startupError = 'VPN-движок не смог запуститься.';
  } catch (e) {
    startupError = 'Ошибка запуска VPN-движка: $e';
  }
  runApp(NovaApp(coreReady: coreReady, startupError: startupError));
}

class VpnServer {
  VpnServer({
    required this.id,
    required this.name,
    required this.protocol,
    required this.host,
    required this.config,
    required this.sourceId,
  });

  final String id;
  final String name;
  final String protocol;
  final String host;
  final String config;
  final String sourceId;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'protocol': protocol,
        'host': host,
        'config': config,
        'sourceId': sourceId,
      };

  factory VpnServer.fromJson(Map<String, dynamic> json) => VpnServer(
        id: json['id'] as String,
        name: json['name'] as String,
        protocol: json['protocol'] as String,
        host: json['host'] as String,
        config: json['config'] as String,
        sourceId: json['sourceId'] as String,
      );
}

class SubscriptionSource {
  SubscriptionSource({
    required this.id,
    required this.name,
    required this.url,
    required this.servers,
  });

  final String id;
  final String name;
  final String url;
  final List<VpnServer> servers;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'url': url,
        'servers': servers.map((e) => e.toJson()).toList(),
      };

  factory SubscriptionSource.fromJson(Map<String, dynamic> json) =>
      SubscriptionSource(
        id: json['id'] as String,
        name: json['name'] as String,
        url: json['url'] as String,
        servers: (json['servers'] as List)
            .map((e) => VpnServer.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

class NovaApp extends StatefulWidget {
  const NovaApp({super.key, required this.coreReady, this.startupError});
  final bool coreReady;
  final String? startupError;

  @override
  State<NovaApp> createState() => _NovaAppState();
}

class _NovaAppState extends State<NovaApp> {
  Color accent = const Color(0xFF4388FF);

  @override
  void initState() {
    super.initState();
    _loadTheme();
  }

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final value = prefs.getInt(_themeKey);
    if (value != null && mounted) setState(() => accent = Color(value));
  }

  Future<void> _setTheme(Color color) async {
    setState(() => accent = color);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_themeKey, color.value);
  }

  @override
  Widget build(BuildContext context) {
    final dark = ThemeData(
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(
        seedColor: accent,
        brightness: Brightness.dark,
        surface: const Color(0xFF151E32),
      ),
      scaffoldBackgroundColor: const Color(0xFF0B1020),
      cardColor: const Color(0xFF151E32),
      useMaterial3: true,
    );
    return MaterialApp(
      title: 'NovaVPN',
      debugShowCheckedModeBanner: false,
      theme: dark,
      home: HomePage(
        coreReady: widget.coreReady,
        startupError: widget.startupError,
        accent: accent,
        onAccentChanged: _setTheme,
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({
    super.key,
    required this.coreReady,
    required this.startupError,
    required this.accent,
    required this.onAccentChanged,
  });

  final bool coreReady;
  final String? startupError;
  final Color accent;
  final ValueChanged<Color> onAccentChanged;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _urlController = TextEditingController();
  final List<SubscriptionSource> _sources = [];
  final List<VpnServer> _servers = [];
  StreamSubscription<SingBoxConnectionStatus>? _statusSub;
  StreamSubscription<SingBoxConnectionStats>? _statsSub;
  SingBoxConnectionStatus _status = SingBoxConnectionStatus.disconnected;
  SingBoxConnectionStats? _stats;
  String? _selectedId;
  bool _busy = false;
  String? _message;

  VpnServer? get _selected {
    for (final server in _servers) {
      if (server.id == _selectedId) return server;
    }
    return _servers.isEmpty ? null : _servers.first;
  }

  @override
  void initState() {
    super.initState();
    _loadSaved();
    if (widget.coreReady) {
      _statusSub = SingBox.instance.watchSingBoxConnectionStatus().listen((s) {
        if (mounted) setState(() => _status = s);
      });
      _statsSub = SingBox.instance.watchSingBoxConnectionStats().listen((s) {
        if (mounted) setState(() => _stats = s);
      });
      _syncStatus();
    }
  }

  Future<void> _syncStatus() async {
    try {
      final s = await SingBox.instance.getConnectionStatus();
      if (mounted) setState(() => _status = s);
    } catch (_) {}
  }

  Future<void> _loadSaved() async {
    try {
      final raw = await _storage.read(key: _sourcesKey);
      if (raw == null) return;
      final decoded = jsonDecode(raw) as List;
      final loaded = decoded
          .map((e) => SubscriptionSource.fromJson(
              Map<String, dynamic>.from(e as Map)))
          .toList();
      if (!mounted) return;
      setState(() {
        _sources.addAll(loaded);
        for (final source in loaded) {
          _servers.addAll(source.servers);
        }
        if (_servers.isNotEmpty) _selectedId = _servers.first.id;
      });
    } catch (e) {
      if (mounted) setState(() => _message = 'Не удалось прочитать сохранённые подписки.');
    }
  }

  Future<void> _saveSources() async {
    await _storage.write(
      key: _sourcesKey,
      value: jsonEncode(_sources.map((e) => e.toJson()).toList()),
    );
  }

  Future<void> _addSubscription() async {
    final text = _urlController.text.trim();
    final uri = Uri.tryParse(text);
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
      _show('Вставь корректную HTTPS-ссылку подписки.');
      return;
    }
    setState(() {
      _busy = true;
      _message = 'Загружаю подписку…';
    });
    try {
      final response = await http.get(uri).timeout(const Duration(seconds: 25));
      if (response.statusCode != 200) {
        throw Exception('Сервер вернул HTTP ${response.statusCode}');
      }
      if (response.bodyBytes.length > 2 * 1024 * 1024) {
        throw Exception('Файл подписки слишком большой (лимит 2 МБ).');
      }
      final body = utf8.decode(response.bodyBytes, allowMalformed: true);
      final links = _extractLinks(body);
      final parsed = <VpnServer>[];
      final sourceId = DateTime.now().microsecondsSinceEpoch.toString();
      for (var i = 0; i < links.length; i++) {
        try {
          parsed.add(_parseLink(links[i], sourceId, i));
        } catch (_) {
          // Skip unsupported or malformed entries; report a count below.
        }
      }
      if (parsed.isEmpty) {
        throw Exception('Не найдено поддерживаемых ссылок VLESS или Shadowsocks.');
      }
      final source = SubscriptionSource(
        id: sourceId,
        name: 'Подписка ${_sources.length + 1}',
        url: text,
        servers: parsed,
      );
      setState(() {
        _sources.add(source);
        _servers.addAll(parsed);
        _selectedId = parsed.first.id;
        _urlController.clear();
        _message = 'Добавлено серверов: ${parsed.length}';
      });
      await _saveSources();
    } catch (e) {
      _show('Не удалось добавить подписку: ${e.toString().replaceFirst('Exception: ', '')}');
      setState(() => _message = 'Ошибка загрузки подписки');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  List<String> _extractLinks(String input) {
    var text = input.trim();
    if (!text.contains('://')) {
      final compact = text.replaceAll(RegExp(r'\s+'), '');
      try {
        text = utf8.decode(base64.decode(base64.normalize(compact)));
      } catch (_) {
        try {
          text = utf8.decode(base64Url.decode(base64Url.normalize(compact)));
        } catch (_) {}
      }
    }
    return text
        .split(RegExp(r'[\r\n]+'))
        .map((e) => e.trim())
        .where((e) =>
            e.startsWith('vless://') ||
            e.startsWith('ss://') ||
            e.startsWith('shadowsocks://'))
        .toList();
  }

  VpnServer _parseLink(String link, String sourceId, int index) {
    if (link.startsWith('vless://')) return _parseVless(link, sourceId, index);
    if (link.startsWith('ss://') || link.startsWith('shadowsocks://')) {
      return _parseShadowsocks(link, sourceId, index);
    }
    throw FormatException('Неподдерживаемый протокол');
  }

  VpnServer _parseVless(String link, String sourceId, int index) {
    final uri = Uri.parse(link);
    final uuid = Uri.decodeComponent(uri.userInfo);
    final host = uri.host;
    final port = uri.port;
    if (uuid.isEmpty || host.isEmpty || port <= 0) {
      throw const FormatException('Неполная VLESS-ссылка');
    }
    final q = uri.queryParameters;
    final security = q['security'] ?? 'none';
    final outbound = <String, dynamic>{
      'type': 'vless',
      'tag': 'proxy',
      'server': host,
      'server_port': port,
      'uuid': uuid,
    };
    if ((q['flow'] ?? '').isNotEmpty) outbound['flow'] = q['flow'];
    if (security == 'tls' || security == 'reality') {
      final tls = <String, dynamic>{
        'enabled': true,
        'server_name': q['sni'] ?? q['servername'] ?? host,
        'alpn': (q['alpn'] ?? '').isEmpty
            ? null
            : q['alpn']!.split(','),
      }..removeWhere((key, value) => value == null);
      if ((q['fp'] ?? '').isNotEmpty) {
        tls['utls'] = {'enabled': true, 'fingerprint': q['fp']};
      }
      if (security == 'reality') {
        tls['reality'] = {
          'enabled': true,
          'public_key': q['pbk'] ?? '',
          'short_id': q['sid'] ?? '',
        };
      }
      outbound['tls'] = tls;
    }
    final transport = q['type'] ?? 'tcp';
    if (transport == 'ws') {
      outbound['transport'] = {
        'type': 'ws',
        'path': q['path'] ?? '/',
        if ((q['host'] ?? '').isNotEmpty)
          'headers': {'Host': q['host']},
      };
    } else if (transport == 'grpc') {
      outbound['transport'] = {
        'type': 'grpc',
        'service_name': q['serviceName'] ?? '',
      };
    } else if (transport == 'httpupgrade') {
      outbound['transport'] = {
        'type': 'httpupgrade',
        'path': q['path'] ?? '/',
        if ((q['host'] ?? '').isNotEmpty) 'host': q['host'],
      };
    } else if (transport != 'tcp') {
      throw FormatException('Транспорт $transport пока не поддержан');
    }
    final name = _label(uri, 'VLESS • $host');
    return _makeServer(name, 'VLESS', host, outbound, sourceId, index);
  }

  VpnServer _parseShadowsocks(String link, String sourceId, int index) {
    final uri = Uri.parse(link);
    String method;
    String password;
    String host = uri.host;
    int port = uri.port;
    if (uri.userInfo.isNotEmpty) {
      var user = Uri.decodeComponent(uri.userInfo);
      if (!user.contains(':')) {
        try {
          user = utf8.decode(base64.decode(base64.normalize(user)));
        } catch (_) {}
      }
      final split = user.indexOf(':');
      if (split < 1) throw const FormatException('Неверная Shadowsocks-ссылка');
      method = user.substring(0, split);
      password = user.substring(split + 1);
    } else {
      final raw = link.substring(link.indexOf('://') + 3).split('#').first;
      final decoded = utf8.decode(base64.decode(base64.normalize(raw)));
      final at = decoded.lastIndexOf('@');
      if (at < 1) throw const FormatException('Неверная Shadowsocks-ссылка');
      final credentials = decoded.substring(0, at);
      final address = Uri.parse('ss://${decoded.substring(at + 1)}');
      final split = credentials.indexOf(':');
      if (split < 1) throw const FormatException('Неверные данные доступа');
      method = credentials.substring(0, split);
      password = credentials.substring(split + 1);
      host = address.host;
      port = address.port;
    }
    if (host.isEmpty || port <= 0 || method.isEmpty || password.isEmpty) {
      throw const FormatException('Неполная Shadowsocks-ссылка');
    }
    final outbound = <String, dynamic>{
      'type': 'shadowsocks',
      'tag': 'proxy',
      'server': host,
      'server_port': port,
      'method': method,
      'password': password,
    };
    final name = _label(uri, 'Shadowsocks • $host');
    return _makeServer(name, 'Shadowsocks', host, outbound, sourceId, index);
  }

  String _label(Uri uri, String fallback) {
    final fragment = uri.fragment;
    if (fragment.isEmpty) return fallback;
    try {
      return Uri.decodeComponent(fragment);
    } catch (_) {
      return fragment;
    }
  }

  VpnServer _makeServer(
    String name,
    String protocol,
    String host,
    Map<String, dynamic> proxy,
    String sourceId,
    int index,
  ) {
    final config = jsonEncode({
      'log': {'level': 'warn'},
      'outbounds': [
        proxy,
        {'type': 'direct', 'tag': 'direct'}
      ],
      'route': {'final': 'proxy', 'auto_detect_interface': true}
    });
    return VpnServer(
      id: '$sourceId-$index-${host.hashCode}',
      name: name,
      protocol: protocol,
      host: host,
      config: config,
      sourceId: sourceId,
    );
  }

  Future<void> _connect() async {
    final server = _selected;
    if (server == null) {
      _show('Сначала добавь подписку и выбери сервер.');
      return;
    }
    setState(() => _busy = true);
    try {
      final ok = await SingBox.instance.connect(server.config);
      if (!ok) _show('Движок не смог начать подключение. Проверь ссылку и сервер.');
    } catch (e) {
      _show('Ошибка подключения: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
      await _syncStatus();
    }
  }

  Future<void> _disconnect() async {
    setState(() => _busy = true);
    try {
      await SingBox.instance.disconnect();
    } catch (e) {
      _show('Ошибка отключения: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
      await _syncStatus();
    }
  }

  Future<void> _refreshSource(SubscriptionSource source) async {
    _urlController.text = source.url;
    await _removeSource(source.id, save: false);
    await _addSubscription();
  }

  Future<void> _removeSource(String id, {bool save = true}) async {
    if (_status == SingBoxConnectionStatus.connected &&
        _selected?.sourceId == id) {
      await _disconnect();
    }
    setState(() {
      _sources.removeWhere((s) => s.id == id);
      _servers.removeWhere((s) => s.sourceId == id);
      if (!_servers.any((s) => s.id == _selectedId)) {
        _selectedId = _servers.isEmpty ? null : _servers.first.id;
      }
    });
    if (save) await _saveSources();
  }

  Future<void> _ping() async {
    if (_status != SingBoxConnectionStatus.connected) {
      _show('Сначала подключись к серверу.');
      return;
    }
    try {
      final result = await SingBox.instance.pingCurrentServer();
      _show(result.success
          ? 'Ping: ${result.ping} мс'
          : 'Ping не удался: ${result.errorMessage ?? "нет ответа"}');
    } catch (e) {
      _show('Ошибка ping: $e');
    }
  }

  void _show(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  void dispose() {
    _urlController.dispose();
    _statusSub?.cancel();
    _statsSub?.cancel();
    super.dispose();
  }

  String get _statusText {
    switch (_status) {
      case SingBoxConnectionStatus.connected:
        return 'Подключено';
      case SingBoxConnectionStatus.connecting:
        return 'Подключение…';
      case SingBoxConnectionStatus.disconnecting:
        return 'Отключение…';
      case SingBoxConnectionStatus.connectionLost:
        return 'Соединение потеряно';
      case SingBoxConnectionStatus.error:
        return 'Ошибка подключения';
      default:
        return 'Отключено';
    }
  }

  @override
  Widget build(BuildContext context) {
    final connected = _status == SingBoxConnectionStatus.connected;
    final speed = _stats;
    return Scaffold(
      appBar: AppBar(
        title: const Text('NovaVPN', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            tooltip: 'Настройки и темы',
            onPressed: _showSettings,
            icon: const Icon(Icons.tune),
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (!widget.coreReady)
            _panel(
              child: Text(
                widget.startupError ?? 'VPN-движок недоступен.',
                style: const TextStyle(color: Colors.orangeAccent),
              ),
            ),
          _panel(
            child: Column(
              children: [
                const Text('ЗАЩИЩЁННОЕ ПОДКЛЮЧЕНИЕ',
                    style: TextStyle(letterSpacing: 1.1, fontSize: 12)),
                const SizedBox(height: 10),
                Icon(
                  connected ? Icons.shield : Icons.shield_outlined,
                  size: 42,
                  color: connected ? Colors.greenAccent : widget.accent,
                ),
                const SizedBox(height: 8),
                Text(_statusText,
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                if (speed != null) ...[
                  const SizedBox(height: 8),
                  Text('↓ ${_formatSpeed(speed.downloadSpeed)}   ↑ ${_formatSpeed(speed.uploadSpeed)}',
                      style: const TextStyle(color: Colors.white70)),
                ],
                const SizedBox(height: 18),
                SizedBox(
                  width: 170,
                  height: 58,
                  child: FilledButton(
                    onPressed: _busy || !widget.coreReady
                        ? null
                        : connected
                            ? _disconnect
                            : _connect,
                    child: _busy
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : Text(connected ? 'ОТКЛЮЧИТЬ' : 'ПОДКЛЮЧИТЬ'),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  _selected?.name ?? 'Добавь ссылку подписки ниже',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white60, fontSize: 12),
                ),
              ],
            ),
          ),
          _panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Добавить подписку',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                TextField(
                  controller: _urlController,
                  keyboardType: TextInputType.url,
                  autocorrect: false,
                  decoration: const InputDecoration(
                    hintText: 'https://…',
                    labelText: 'Ссылка подписки',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.link),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _busy ? null : _addSubscription,
                    icon: const Icon(Icons.add_link),
                    label: const Text('Добавить подписку'),
                  ),
                ),
                if (_message != null) ...[
                  const SizedBox(height: 8),
                  Text(_message!, style: const TextStyle(color: Colors.white60)),
                ],
                const SizedBox(height: 5),
                const Text('Поддерживаемые ссылки: VLESS (TCP/TLS/Reality, WS, gRPC) и Shadowsocks.',
                    style: TextStyle(color: Colors.white54, fontSize: 12)),
              ],
            ),
          ),
          _panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Expanded(
                      child: Text('Серверы',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    ),
                    Text('${_servers.length}', style: const TextStyle(color: Colors.white60)),
                  ],
                ),
                if (_servers.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 20),
                    child: Text('Пока нет серверов. Добавь ссылку подписки.',
                        style: TextStyle(color: Colors.white60)),
                  ),
                ..._servers.map((server) {
                  final selected = server.id == _selectedId;
                  return Card(
                    color: selected ? widget.accent.withOpacity(.18) : const Color(0xFF10192B),
                    child: ListTile(
                      leading: Icon(
                        selected ? Icons.radio_button_checked : Icons.public,
                        color: selected ? widget.accent : Colors.white70,
                      ),
                      title: Text(server.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text('${server.protocol} • ${server.host}',
                          maxLines: 1, overflow: TextOverflow.ellipsis),
                      trailing: selected
                          ? const Icon(Icons.check_circle, color: Colors.greenAccent)
                          : const Icon(Icons.chevron_right),
                      onTap: () async {
                        if (connected) await _disconnect();
                        setState(() => _selectedId = server.id);
                      },
                    ),
                  );
                }),
                if (_servers.isNotEmpty)
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      onPressed: _ping,
                      icon: const Icon(Icons.speed),
                      label: const Text('Проверить ping'),
                    ),
                  ),
              ],
            ),
          ),
          _panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Мои подписки',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                if (_sources.isEmpty)
                  const Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: Text('Подписок пока нет',
                        style: TextStyle(color: Colors.white60)),
                  ),
                ..._sources.map((source) => ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.rss_feed),
                      title: Text(source.name),
                      subtitle: Text('${source.servers.length} серверов',
                          style: const TextStyle(color: Colors.white60)),
                      trailing: PopupMenuButton<String>(
                        onSelected: (value) {
                          if (value == 'refresh') _refreshSource(source);
                          if (value == 'remove') _removeSource(source.id);
                        },
                        itemBuilder: (_) => const [
                          PopupMenuItem(value: 'refresh', child: Text('Обновить')),
                          PopupMenuItem(value: 'remove', child: Text('Удалить')),
                        ],
                      ),
                    )),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text(
              'NovaVPN • Используй только подписки, на использование которых у тебя есть разрешение.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white38, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }

  Widget _panel({required Widget child}) => Card(
        margin: const EdgeInsets.only(bottom: 14),
        child: Padding(padding: const EdgeInsets.all(16), child: child),
      );

  String _formatSpeed(int bytes) {
    if (bytes < 1024) return '$bytes B/s';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB/s';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB/s';
  }

  Future<void> _showSettings() async {
    final colors = <Color>[
      const Color(0xFF4388FF),
      const Color(0xFF10B981),
      const Color(0xFFA855F7),
      const Color(0xFFF43F5E),
      const Color(0xFFF59E0B),
      const Color(0xFF06B6D4),
      const Color(0xFFE5E7EB),
    ];
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF151E32),
      showDragHandle: true,
      builder: (context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Внешний вид',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            const Text('Цвет NovaVPN'),
            const SizedBox(height: 12),
            Wrap(
              spacing: 14,
              children: colors
                  .map((color) => InkWell(
                        onTap: () {
                          widget.onAccentChanged(color);
                          Navigator.pop(context);
                        },
                        child: CircleAvatar(
                          radius: 20,
                          backgroundColor: color,
                          child: widget.accent.value == color.value
                              ? const Icon(Icons.check, color: Colors.black)
                              : null,
                        ),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 20),
            const Text(
              'Для отключения защиты при обрыве соединения можно включить системный Always-on VPN в настройках Android после установки.',
              style: TextStyle(color: Colors.white60, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
